1. To run

:~$ python main.py 
Total Count of Concatenated Words: 97107
The Longest Concatenated Word:
  ethylenediaminetetraacetates
The 2nd Longest Concatenated Words:
  ethylenediaminetetraacetate
  electroencephalographically


2. Comments

  -  Very interesting problem! Inspired by my previous BearMap project that requires making a map of Berkeley and surroundings and showing a list of suggested locations when a user types a word in the search box, I thought of using Trie.

  - My first Trie took one and half hour to run. My second approach took ~1min 30s. My last one took ~45s.

